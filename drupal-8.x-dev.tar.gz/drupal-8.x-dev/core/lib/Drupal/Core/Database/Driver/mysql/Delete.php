<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\mysql\Delete
 */

namespace Drupal\Core\Database\Driver\mysql;

use Drupal\Core\Database\Query\Delete as QueryDelete;

class Delete extends QueryDelete { }
