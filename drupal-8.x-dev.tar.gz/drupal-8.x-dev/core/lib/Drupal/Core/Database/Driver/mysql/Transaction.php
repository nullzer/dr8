<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\mysql\Transaction
 */

namespace Drupal\Core\Database\Driver\mysql;

use Drupal\Core\Database\Transaction as DatabaseTransaction;

class Transaction extends DatabaseTransaction { }
