<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\pgsql\Truncate
 */

namespace Drupal\Core\Database\Driver\pgsql;

use Drupal\Core\Database\Query\Truncate as QueryTruncate;

class Truncate extends QueryTruncate { }
